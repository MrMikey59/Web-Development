(function(root) {
	'use strict';

	var CSSOM = root.CSSOM = {};
